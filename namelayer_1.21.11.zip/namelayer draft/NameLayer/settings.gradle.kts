pluginManagement {
    repositories {
        gradlePluginPortal()
        maven("https://papermc.io/repo/repository/maven-public/")
    }
    plugins {
        id("io.papermc.paperweight.userdev") version "2.0.0-beta.21"
    }
}

rootProject.name = "namelayer"

include(":paper")
project(":paper").name = rootProject.name + "-paper"
