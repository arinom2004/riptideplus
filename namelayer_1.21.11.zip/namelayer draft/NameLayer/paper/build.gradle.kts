plugins {
    id("io.papermc.paperweight.userdev")
}

dependencies {
    paperweight.paperDevBundle("1.21.11-R0.1-SNAPSHOT")
    compileOnly("net.civmc.civmodcore:civmodcore-paper:3.0.0")
}

tasks.withType<ProcessResources> {
    filesMatching("plugin.yml") {
        expand(mapOf(
            "name" to "NameLayer",
            "version" to project.version
        ))
    }
}
